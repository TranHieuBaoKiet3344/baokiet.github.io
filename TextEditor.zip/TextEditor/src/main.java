import controller.texteditorController;
import view.texteditorView;

public class main {
    public static void main(String[] args) {
        new texteditorController(new texteditorView());
    }
}